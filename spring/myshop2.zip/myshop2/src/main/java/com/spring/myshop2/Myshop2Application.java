package com.spring.myshop2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Myshop2Application {

	public static void main(String[] args) {
		SpringApplication.run(Myshop2Application.class, args);
	}

}
