package com.example.googleLogin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GoogleLoginApplicationTests {

	@Test
	void contextLoads() {
	}

}
