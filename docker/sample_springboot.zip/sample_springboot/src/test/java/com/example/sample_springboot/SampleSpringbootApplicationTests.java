package com.example.sample_springboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SampleSpringbootApplicationTests {

	@Test
	void contextLoads() {
	}

}
