package com.project.VisitBusan;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VisitBusanApplicationTests {

	@Test
	void contextLoads() {
	}

}
